import random

def number_guessing_game():
    print("👋 Hey there! Welcome to the Number Guessing Game!")
    print("🔢 I'm thinking of a number between 1 and 100.")
    print("💡 Your job is to guess what it is. I’ll help you out along the way!")
    print("Let's begin...\n")

    # Generate a random number between 1 and 100
    secret_number = random.randint(1, 100)
    attempts = 0

    while True:
        try:
            guess = int(input("🤔 What's your guess? "))

            if guess < 1 or guess > 100:
                print("⚠️ Oops! Please choose a number *between 1 and 100.*")
                continue

            attempts += 1

            if guess < secret_number:
                print("🔻 Too low! Try a *bigger* number.\n")
            elif guess > secret_number:
                print("🔺 Too high! Try a *smaller* number.\n")
            else:
                print(f"🎉 Woohoo! You got it! The number was {secret_number}.")
                print(f"✅ It took you {attempts} attempt{'s' if attempts > 1 else ''}. Nice job!")
                break

        except ValueError:
            print("⚠️ That doesn’t look like a number. Try typing a number next time!\n")

if __name__ == "__main__":
    number_guessing_game()
