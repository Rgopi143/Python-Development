import requests

def get_exchange_rates(api_key):
    url = f"https://openexchangerates.org/api/latest.json?app_id={api_key}"
    response = requests.get(url)
    if response.status_code == 200:
        data = response.json()
        return data['rates']
    else:
        print("Oops! Something went wrong. Please check the API key and internet connection.")
        return None

def convert_currency(amount, from_currency, to_currency, exchange_rates):
    if from_currency == 'USD':
        rate_from = 1
    else:
        rate_from = exchange_rates[from_currency]
        
    if to_currency == 'USD':
        rate_to = 1
    else:
        rate_to = exchange_rates[to_currency]

    converted_amount = (amount / rate_from) * rate_to
    return converted_amount

def currency_converter():
    print("Welcome to the Currency Converter! Let's get started.")
    api_key = input("Please enter your Open Exchange Rates API Key: ").strip()
    exchange_rates = get_exchange_rates(api_key)
    
    if exchange_rates is None:
        return
    
    print("\nHere are some available currencies: USD, EUR, GBP, JPY, AUD, CAD, CHF, CNY, INR, etc.\n")
    
    from_currency = input("What currency do you want to convert from? (e.g., USD, EUR): ").upper().strip()
    to_currency = input("What currency do you want to convert to? (e.g., USD, EUR): ").upper().strip()
    amount = float(input(f"How much {from_currency} do you want to convert? ").strip())

    if from_currency not in exchange_rates or to_currency not in exchange_rates:
        print("Oops! Invalid currency entered. Please check the currency codes and try again.")
        return

    converted_amount = convert_currency(amount, from_currency, to_currency, exchange_rates)
    
    print(f"\n{amount} {from_currency} is equal to {converted_amount:.2f} {to_currency}")

if __name__ == "__main__":
    currency_converter()
