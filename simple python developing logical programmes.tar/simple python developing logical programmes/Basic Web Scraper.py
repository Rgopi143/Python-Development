import requests
from bs4 import BeautifulSoup
import csv

def scrape_headlines(url):
    try:
        print(f"\n🔗 Connecting to {url}... Let's fetch the latest headlines!")
        response = requests.get(url)
        response.raise_for_status()

        soup = BeautifulSoup(response.text, 'html.parser')

        print("\n📰 Great! Now, extracting headlines from the page...")
        headlines = soup.find_all(['h1', 'h2', 'h3'])
        if not headlines:
            raise ValueError("Hmm, no headlines found. The page structure might have changed!")

        print("\nHere are the first few headlines I found:")
        for i, headline in enumerate(headlines[:5], start=1):
            text = headline.get_text(strip=True)
            if text:
                print(f"{i}. {text}")

        with open('headlines.txt', 'w', encoding='utf-8') as file:
            print("\n💾 Saving headlines to 'headlines.txt'...")
            for headline in headlines:
                text = headline.get_text(strip=True)
                if text:
                    file.write(f"{text}\n")
        print("✅ Headlines successfully saved to 'headlines.txt'.")

        with open('headlines.csv', 'w', newline='', encoding='utf-8') as file:
            writer = csv.writer(file)
            writer.writerow(['Headline'])
            print("💾 Saving headlines to 'headlines.csv'...")
            for headline in headlines:
                text = headline.get_text(strip=True)
                if text:
                    writer.writerow([text])
        print("✅ Headlines successfully saved to 'headlines.csv'.")

    except requests.exceptions.RequestException as e:
        print(f"🚫 Oops! There was an issue connecting to the website: {e}")
    except ValueError as e:
        print(f"⚠️ {e}")
    except Exception as e:
        print(f"⚠️ Something unexpected happened: {e}")

if __name__ == "__main__":
    print("🌐 Welcome to the News Headline Scraper! Let's grab some headlines.")

    use_default = input("Would you like to use the default BBC News URL? (y/n): ").strip().lower()

    if use_default == 'n':
        url = input("🔍 Please enter the URL of the news website you'd like to scrape: ").strip()
    else:
        url = "https://www.bbc.com/news"

    scrape_headlines(url)
