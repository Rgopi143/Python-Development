from collections import Counter
import string

def analyze_text_file(file_path):
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            text = file.read()

            lines = text.splitlines()
            num_lines = len(lines)

            words = text.split()
            num_words = len(words)
            num_chars = len(text)

            words_cleaned = [word.strip(string.punctuation).lower() for word in words]
            word_frequency = Counter(words_cleaned)

            print(f"\n🎉 Analysis Complete for the file: {file_path}")
            print(f"📄 Total Lines: {num_lines}")
            print(f"📚 Total Words: {num_words}")
            print(f"🔠 Total Characters: {num_chars}")
            
            print("\n🔍 Top 10 Most Common Words:")
            for word, freq in word_frequency.most_common(10):
                print(f"🔑 {word}: {freq}")

    except FileNotFoundError:
        print(f"😟 Oops! We couldn't find the file at '{file_path}'. Please check the file path and try again.")
    except Exception as e:
        print(f"😞 Something went wrong: {e}")

if __name__ == "__main__":
    file_path = input("🌟 Let's analyze a text file! Please enter the file path: ").strip()
    analyze_text_file(file_path)
