# Task class represents each to-do item
class Task:
    def __init__(self, description):
        self.description = description
        self.completed = False

    def mark_completed(self):
        self.completed = True

    def __str__(self):
        status = "Done" if self.completed else "Pending"
        return f"{self.description} - [{status}]"


# ToDoList class manages the list of tasks
class ToDoList:
    def __init__(self):
        self.tasks = []

    def add_task(self, description):
        new_task = Task(description)
        self.tasks.append(new_task)
        print("Task added.")

    def show_tasks(self):
        if not self.tasks:
            print("No tasks yet.")
        else:
            print("\n--- Your Tasks ---")
            for idx, task in enumerate(self.tasks, start=1):
                print(f"{idx}. {task}")
            print("------------------")

    def complete_task(self, task_number):
        if 1 <= task_number <= len(self.tasks):
            self.tasks[task_number - 1].mark_completed()
            print("Task marked as completed.")
        else:
            print("Invalid task number.")


# Main interface loop
def main():
    todo_list = ToDoList()

    while True:
        print("\n========== TO-DO LIST MENU ==========")
        print("1. Add Task")
        print("2. Show Tasks")
        print("3. Complete a Task")
        print("4. Exit")
        print("=====================================")

        choice = input("Enter your choice (1-4): ")

        if choice == "1":
            description = input("Enter task description: ")
            todo_list.add_task(description)
        elif choice == "2":
            todo_list.show_tasks()
        elif choice == "3":
            todo_list.show_tasks()
            try:
                task_number = int(input("Enter the task number to complete: "))
                todo_list.complete_task(task_number)
            except ValueError:
                print("Please enter a valid number.")
        elif choice == "4":
            print("Exiting. Goodbye!")
            break
        else:
            print("Invalid choice. Try again.")


if __name__ == "__main__":
    main()
