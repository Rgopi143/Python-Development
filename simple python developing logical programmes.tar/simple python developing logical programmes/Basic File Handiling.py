def find_and_replace_in_file(file_path, target_word, replacement_word):
    try:
        # Try to open and read the file
        with open(file_path, 'r') as file:
            content = file.read()

        # Let the user know the process has started
        print(f"\n🔍 Looking for the word '{target_word}'...")

        # Replace the target word
        updated_content = content.replace(target_word, replacement_word)

        # Save the changes
        with open(file_path, 'w') as file:
            file.write(updated_content)

        print(f"✅ Done! All instances of '{target_word}' have been replaced with '{replacement_word}' in '{file_path}'.\n")

    except FileNotFoundError:
        print(f"🚫 Oops! The file '{file_path}' doesn't exist. Please double-check the name and path.")
    except PermissionError:
        print(f"🔒 Hmm... It looks like you don't have permission to access '{file_path}'. Try running the program with proper permissions.")
    except Exception as e:
        print(f"⚠️ Something unexpected happened: {e}")


# Main program starts here
if __name__ == "__main__":
    print("📄 Welcome to the Friendly File Word Replacer!")
    print("This tool helps you quickly find and replace words in a text file.\n")

    # Ask the user for input
    file_path = input("📁 What is the name or path of the text file you'd like to edit? ").strip()
    target_word = input("🔍 Which word would you like to replace? ").strip()
    replacement_word = input("✏️ What word should we use instead? ").strip()

    # Run the word replacement
    find_and_replace_in_file(file_path, target_word, replacement_word)
